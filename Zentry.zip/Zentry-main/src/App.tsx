import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/useAuth";
import AppLayout from "@/components/AppLayout";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import Movimientos from "./pages/Movimientos";
import Cuentas from "./pages/Cuentas";
import Prestamos from "./pages/Prestamos";
import Presupuesto from "./pages/Presupuesto";
import CierreMensual from "./pages/CierreMensual";
import TarjetasCredito from "./pages/TarjetasCredito";
import Datos from "./pages/Datos";
import Configuracion from "./pages/Configuracion";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 30_000, refetchOnWindowFocus: false } },
});

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner richColors theme="dark" position="top-right" />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/auth" element={<Auth />} />
            <Route element={<AppLayout />}>
              <Route path="/" element={<Dashboard />} />
              <Route path="/movimientos" element={<Movimientos />} />
              <Route path="/cuentas" element={<Cuentas />} />
              <Route path="/prestamos" element={<Prestamos />} />
              <Route path="/presupuesto" element={<Presupuesto />} />
              <Route path="/cierre-mensual" element={<CierreMensual />} />
              <Route path="/tarjetas-credito" element={<TarjetasCredito />} />
              <Route path="/datos" element={<Datos />} />
              <Route path="/configuracion" element={<Configuracion />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
