import type { Account, Transaction } from "@/hooks/useFinanceData";

/**
 * Compute the calculated balance for an account up to (and including) a given cutoff date.
 * Uses the most recent monthly_closing BEFORE the cutoff month as the starting point,
 * then applies all transactions strictly after that closing's last day, up to and
 * including the cutoff date (YYYY-MM-DD).
 */
export const computeBalanceUpTo = (
  account: Account,
  txs: Transaction[],
  closings: any[],
  cutoffDate: string, // YYYY-MM-DD inclusive
): { pen: number; usd: number } => {
  // Find the latest closing whose (year, month) is strictly before the cutoff month
  const [cy, cm] = cutoffDate.split("-").map(Number);
  const cutoffMonthIdx = cy * 12 + (cm - 1);

  const accClosings = closings
    .filter((c) => c.account_id === account.id)
    .filter((c) => c.year * 12 + (c.month - 1) < cutoffMonthIdx)
    .sort((a, b) => (b.year - a.year) || (b.month - a.month));
  const last = accClosings[0];

  let basePen = Number(account.initial_balance || 0);
  let baseUsd = 0;
  let startCutoff = "0000-00-00";

  if (last) {
    basePen = Number(last.real_balance_pen || 0);
    baseUsd = Number(last.real_balance_usd || 0);
    const lastDay = new Date(last.year, last.month, 0).getDate();
    startCutoff = `${last.year}-${String(last.month).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`;
  }

  let pen = basePen;
  let usd = baseUsd;
  txs.forEach((t) => {
    if (t.tx_date <= startCutoff) return;
    if (t.tx_date > cutoffDate) return;
    if (t.tx_type === "expense" && t.payment_account_id === account.id) {
      pen -= Number(t.amount_pen || 0);
      usd -= Number(t.amount_usd || 0);
    } else if (t.tx_type === "income" && t.payment_account_id === account.id) {
      pen += Number(t.amount_pen || 0);
      usd += Number(t.amount_usd || 0);
    } else if (t.tx_type === "transfer") {
      if (t.origin_account_id === account.id) {
        pen -= Number(t.amount_pen || 0);
        usd -= Number(t.amount_usd || 0);
      }
      if (t.destination_account_id === account.id) {
        pen += Number(t.amount_pen || 0);
        usd += Number(t.amount_usd || 0);
      }
    }
  });

  return { pen, usd };
};

/** Last day of a given (year, month) as YYYY-MM-DD */
export const lastDayOfMonth = (year: number, month: number) => {
  const d = new Date(year, month, 0).getDate();
  return `${year}-${String(month).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
};
