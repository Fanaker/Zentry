import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type Account = {
  id: string;
  name: string;
  account_type: "debit" | "credit" | "cash" | "dollars" | "other";
  currency: "PEN" | "USD";
  counts_as_real_money: boolean;
  initial_balance: number;
  is_active: boolean;
  display_order: number;
  billing_start_day?: number | null;
  billing_end_day?: number | null;
};

export type Category = {
  id: string;
  name: string;
  tx_type: "expense" | "income" | "transfer";
  is_active: boolean;
};

export type Person = { id: string; name: string };

export type Transaction = {
  id: string;
  tx_date: string;
  tx_type: "expense" | "income" | "transfer";
  payment_account_id: string | null;
  origin_account_id: string | null;
  destination_account_id: string | null;
  person_id: string | null;
  category_id: string | null;
  description: string | null;
  amount_pen: number;
  amount_usd: number;
  currency: "PEN" | "USD";
  created_at: string;
};

export const useAccounts = () =>
  useQuery({
    queryKey: ["accounts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("accounts")
        .select("*")
        .order("display_order");
      if (error) throw error;
      return (data ?? []) as Account[];
    },
  });

export const useCategories = () =>
  useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("categories")
        .select("*")
        .order("name");
      if (error) throw error;
      return (data ?? []) as Category[];
    },
  });

export const usePeople = () =>
  useQuery({
    queryKey: ["people"],
    queryFn: async () => {
      const { data, error } = await supabase.from("people").select("*").order("name");
      if (error) throw error;
      return (data ?? []) as Person[];
    },
  });

export const useTransactions = () =>
  useQuery({
    queryKey: ["transactions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("transactions")
        .select("*")
        .order("tx_date", { ascending: false })
        .order("created_at", { ascending: false })
        .limit(5000);
      if (error) throw error;
      return (data ?? []) as Transaction[];
    },
  });

export const useMonthlyClosings = () =>
  useQuery({
    queryKey: ["monthly_closings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("monthly_closings")
        .select("*")
        .order("year", { ascending: false })
        .order("month", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

export const useBudgets = () =>
  useQuery({
    queryKey: ["budgets"],
    queryFn: async () => {
      const { data, error } = await supabase.from("budgets").select("*");
      if (error) throw error;
      return data ?? [];
    },
  });
