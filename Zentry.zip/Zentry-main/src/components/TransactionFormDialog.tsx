import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useAccounts, useCategories, usePeople, type Transaction } from "@/hooks/useFinanceData";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

const schema = z.object({
  tx_date: z.string().min(1, "Fecha requerida"),
  tx_type: z.enum(["expense", "income", "transfer"]),
  payment_account_id: z.string().optional(),
  origin_account_id: z.string().optional(),
  destination_account_id: z.string().optional(),
  category_id: z.string().optional(),
  person_id: z.string().optional(),
  description: z.string().max(500).optional(),
  amount_pen: z.coerce.number().min(0).default(0),
  amount_usd: z.coerce.number().min(0).default(0),
  currency: z.enum(["PEN", "USD"]).default("PEN"),
});
type FormVals = z.infer<typeof schema>;

interface Props {
  open: boolean;
  onClose: () => void;
  initial?: Transaction | null;
  /** Prefill values for a NEW movement (used when duplicating). */
  prefill?: Transaction | null;
}

const NONE = "__none__";

export default function TransactionFormDialog({ open, onClose, initial, prefill }: Props) {
  const qc = useQueryClient();
  const { user } = useAuth();
  const { data: accounts = [] } = useAccounts();
  const { data: categories = [] } = useCategories();
  const { data: people = [] } = usePeople();
  const [submitting, setSubmitting] = useState(false);
  const [newPerson, setNewPerson] = useState("");

  const buildValuesFrom = (t: Transaction): FormVals => ({
    tx_date: t.tx_date,
    tx_type: t.tx_type,
    payment_account_id: t.payment_account_id ?? undefined,
    origin_account_id: t.origin_account_id ?? undefined,
    destination_account_id: t.destination_account_id ?? undefined,
    category_id: t.category_id ?? undefined,
    person_id: t.person_id ?? undefined,
    description: t.description ?? "",
    amount_pen: Number(t.amount_usd) > 0 && Number(t.amount_pen) === 0
      ? Number(t.amount_usd)
      : Number(t.amount_pen),
    amount_usd: 0,
    currency: Number(t.amount_usd) > 0 && Number(t.amount_pen) === 0 ? "USD" : t.currency,
  });

  const emptyValues: FormVals = {
    tx_date: new Date().toISOString().slice(0, 10),
    tx_type: "expense",
    amount_pen: 0,
    amount_usd: 0,
    currency: "PEN",
  };

  const form = useForm<FormVals>({
    resolver: zodResolver(schema),
    defaultValues: initial ? buildValuesFrom(initial) : prefill ? buildValuesFrom(prefill) : emptyValues,
  });

  // Re-sync the form whenever the dialog opens with a new record (edit/duplicate/new)
  useEffect(() => {
    if (!open) return;
    if (initial) form.reset(buildValuesFrom(initial));
    else if (prefill) form.reset(buildValuesFrom(prefill));
    else form.reset(emptyValues);
    setNewPerson("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, initial?.id, prefill?.id]);

  const txType = form.watch("tx_type");
  const currency = form.watch("currency");
  const filteredCats = categories.filter((c) => c.tx_type === txType);

  const ensurePerson = async (): Promise<string | null> => {
    const sel = form.getValues("person_id");
    if (sel && sel !== NONE) return sel;
    if (!newPerson.trim()) return null;
    const { data, error } = await supabase
      .from("people")
      .insert({ name: newPerson.trim() })
      .select("id")
      .single();
    if (error) {
      const { data: existing } = await supabase
        .from("people").select("id").eq("name", newPerson.trim()).maybeSingle();
      return existing?.id ?? null;
    }
    return data?.id ?? null;
  };

  const onSubmit = async (vals: FormVals) => {
    setSubmitting(true);
    try {
      const personId = await ensurePerson();
      const cleanId = (v: string | undefined) => (v && v !== NONE ? v : null);

      // Single amount input: route to the right currency column
      const amount = Number(vals.amount_pen) || 0; // we store the typed amount in amount_pen
      const amountPEN = vals.currency === "PEN" ? amount : 0;
      const amountUSD = vals.currency === "USD" ? amount : 0;

      const payload: any = {
        tx_date: vals.tx_date,
        tx_type: vals.tx_type,
        description: vals.description?.trim() || null,
        amount_pen: amountPEN,
        amount_usd: amountUSD,
        currency: vals.currency,
        category_id: cleanId(vals.category_id),
        person_id: personId,
        payment_account_id: vals.tx_type === "transfer" ? null : cleanId(vals.payment_account_id),
        origin_account_id: vals.tx_type === "transfer" ? cleanId(vals.origin_account_id) : null,
        destination_account_id: vals.tx_type === "transfer" ? cleanId(vals.destination_account_id) : null,
      };

      if (initial) {
        const { error } = await supabase.from("transactions").update(payload).eq("id", initial.id);
        if (error) throw error;
        toast.success("Movimiento actualizado");
      } else {
        const { error } = await supabase
          .from("transactions")
          .insert({ ...payload, created_by: user?.id });
        if (error) throw error;
        toast.success("Movimiento registrado");
      }
      qc.invalidateQueries({ queryKey: ["transactions"] });
      qc.invalidateQueries({ queryKey: ["people"] });
      onClose();
      form.reset();
      setNewPerson("");
    } catch (err: any) {
      toast.error(err.message ?? "Error al guardar");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initial ? "Editar movimiento" : "Nuevo movimiento"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Fecha</Label>
              <Input type="date" {...form.register("tx_date")} />
            </div>
            <div>
              <Label>Tipo</Label>
              <Select value={form.watch("tx_type")} onValueChange={(v) => form.setValue("tx_type", v as any)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="expense">Gasto</SelectItem>
                  <SelectItem value="income">Ingreso</SelectItem>
                  <SelectItem value="transfer">TI (Transferencia interna)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {txType !== "transfer" ? (
            <div>
              <Label>Medio de pago</Label>
              <Select
                value={form.watch("payment_account_id") ?? NONE}
                onValueChange={(v) => form.setValue("payment_account_id", v)}
              >
                <SelectTrigger><SelectValue placeholder="Selecciona cuenta" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value={NONE}>—</SelectItem>
                  {accounts.map((a) => (
                    <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Origen</Label>
                <Select
                  value={form.watch("origin_account_id") ?? NONE}
                  onValueChange={(v) => form.setValue("origin_account_id", v)}
                >
                  <SelectTrigger><SelectValue placeholder="Origen" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value={NONE}>—</SelectItem>
                    {accounts.map((a) => (<SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Destino</Label>
                <Select
                  value={form.watch("destination_account_id") ?? NONE}
                  onValueChange={(v) => form.setValue("destination_account_id", v)}
                >
                  <SelectTrigger><SelectValue placeholder="Destino" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value={NONE}>—</SelectItem>
                    {accounts.map((a) => (<SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          <div>
            <Label>Categoría</Label>
            <Select
              value={form.watch("category_id") ?? NONE}
              onValueChange={(v) => form.setValue("category_id", v)}
            >
              <SelectTrigger><SelectValue placeholder="Selecciona categoría" /></SelectTrigger>
              <SelectContent>
                <SelectItem value={NONE}>—</SelectItem>
                {filteredCats.map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Referente a (opcional)</Label>
            <div className="grid grid-cols-2 gap-2">
              <Select
                value={form.watch("person_id") ?? NONE}
                onValueChange={(v) => { form.setValue("person_id", v); setNewPerson(""); }}
              >
                <SelectTrigger><SelectValue placeholder="ND / Persona existente" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value={NONE}>ND (yo mismo)</SelectItem>
                  {people.map((p) => (<SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>))}
                </SelectContent>
              </Select>
              <Input
                placeholder="O nueva persona…"
                value={newPerson}
                onChange={(e) => { setNewPerson(e.target.value); form.setValue("person_id", NONE); }}
              />
            </div>
          </div>

          <div className="grid grid-cols-[1fr,120px] gap-3">
            <div>
              <Label>Monto ({currency === "USD" ? "Dólares" : "Soles"})</Label>
              <Input
                type="number"
                step="0.01"
                placeholder="0.00"
                {...form.register("amount_pen")}
              />
            </div>
            <div>
              <Label>Moneda</Label>
              <Select value={form.watch("currency")} onValueChange={(v) => form.setValue("currency", v as any)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="PEN">S/ PEN</SelectItem>
                  <SelectItem value="USD">$ USD</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label>Descripción</Label>
            <Textarea rows={3} maxLength={500} {...form.register("description")} />
          </div>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button>
            <Button type="submit" disabled={submitting}>
              {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {initial ? "Guardar cambios" : "Crear"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
