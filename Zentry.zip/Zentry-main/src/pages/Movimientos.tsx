import { useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useAccounts, useCategories, usePeople, useTransactions, type Transaction } from "@/hooks/useFinanceData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Plus, Pencil, Trash2, Eye, Search, Copy } from "lucide-react";
import TransactionFormDialog from "@/components/TransactionFormDialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { formatPEN, formatUSD, formatDate, monthsList } from "@/lib/format";
import { toast } from "sonner";

const ALL = "__all__";

const Movimientos = () => {
  const { isAdmin } = useAuth();
  const qc = useQueryClient();
  const { data: accounts = [] } = useAccounts();
  const { data: categories = [] } = useCategories();
  const { data: people = [] } = usePeople();
  const { data: txs = [] } = useTransactions();

  const accountsById = useMemo(() => new Map(accounts.map((a) => [a.id, a])), [accounts]);
  const categoriesById = useMemo(() => new Map(categories.map((c) => [c.id, c])), [categories]);
  const peopleById = useMemo(() => new Map(people.map((p) => [p.id, p])), [people]);

  const [search, setSearch] = useState("");
  const [type, setType] = useState<string>(ALL);
  const [year, setYear] = useState<string>(ALL);
  const [month, setMonth] = useState<string>(ALL);
  const [accountFilter, setAccountFilter] = useState<string>(ALL);
  const [categoryFilter, setCategoryFilter] = useState<string>(ALL);
  const [personFilter, setPersonFilter] = useState<string>(ALL);
  const [editing, setEditing] = useState<Transaction | null>(null);
  const [duplicating, setDuplicating] = useState<Transaction | null>(null);
  const [open, setOpen] = useState(false);
  const [viewing, setViewing] = useState<Transaction | null>(null);

  const years = useMemo(() => {
    const ys = new Set<string>();
    txs.forEach((t) => ys.add(t.tx_date.slice(0, 4)));
    return Array.from(ys).sort().reverse();
  }, [txs]);

  const filtered = useMemo(() => {
    return txs.filter((t) => {
      if (type !== ALL && t.tx_type !== type) return false;
      if (year !== ALL && !t.tx_date.startsWith(year)) return false;
      if (month !== ALL) {
        const m = t.tx_date.slice(5, 7);
        if (m !== month.padStart(2, "0")) return false;
      }
      if (accountFilter !== ALL) {
        if (t.payment_account_id !== accountFilter
          && t.origin_account_id !== accountFilter
          && t.destination_account_id !== accountFilter) return false;
      }
      if (categoryFilter !== ALL && t.category_id !== categoryFilter) return false;
      if (personFilter !== ALL) {
        if (personFilter === "__none__person__") {
          if (t.person_id) return false;
        } else if (t.person_id !== personFilter) return false;
      }
      if (search) {
        const s = search.toLowerCase();
        const cat = t.category_id ? categoriesById.get(t.category_id)?.name ?? "" : "";
        const desc = t.description ?? "";
        if (!cat.toLowerCase().includes(s) && !desc.toLowerCase().includes(s)) return false;
      }
      return true;
    });
  }, [txs, type, year, month, accountFilter, categoryFilter, personFilter, search, categoriesById]);


  const handleDelete = async (id: string) => {
    if (!confirm("¿Eliminar este movimiento?")) return;
    const { error } = await supabase.from("transactions").delete().eq("id", id);
    if (error) toast.error(error.message);
    else {
      toast.success("Movimiento eliminado");
      qc.invalidateQueries({ queryKey: ["transactions"] });
    }
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Movimientos</h1>
          <p className="text-sm text-muted-foreground">{filtered.length} registros</p>
        </div>
        {isAdmin && (
          <Button onClick={() => { setEditing(null); setDuplicating(null); setOpen(true); }}>
            <Plus className="h-4 w-4 mr-1" /> Nuevo movimiento
          </Button>
        )}
      </div>

      <Card className="glass-card">
        <CardContent className="p-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
          <div className="col-span-2 lg:col-span-2 relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              className="pl-9"
              placeholder="Buscar por categoría o descripción…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Select value={type} onValueChange={setType}>
            <SelectTrigger><SelectValue placeholder="Tipo" /></SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Todos los tipos</SelectItem>
              <SelectItem value="expense">Gasto</SelectItem>
              <SelectItem value="income">Ingreso</SelectItem>
              <SelectItem value="transfer">TI</SelectItem>
            </SelectContent>
          </Select>
          <Select value={year} onValueChange={setYear}>
            <SelectTrigger><SelectValue placeholder="Año" /></SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Todos los años</SelectItem>
              {years.map((y) => (<SelectItem key={y} value={y}>{y}</SelectItem>))}
            </SelectContent>
          </Select>
          <Select value={month} onValueChange={setMonth}>
            <SelectTrigger><SelectValue placeholder="Mes" /></SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Todos los meses</SelectItem>
              {monthsList.map((m, i) => (
                <SelectItem key={m} value={String(i + 1).padStart(2, "0")}>{m}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={accountFilter} onValueChange={setAccountFilter}>
            <SelectTrigger><SelectValue placeholder="Cuenta" /></SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Todas las cuentas</SelectItem>
              {accounts.map((a) => (<SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>))}
            </SelectContent>
          </Select>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger><SelectValue placeholder="Categoría" /></SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Todas las categorías</SelectItem>
              {categories.map((c) => (<SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>))}
            </SelectContent>
          </Select>
          <Select value={personFilter} onValueChange={setPersonFilter}>
            <SelectTrigger><SelectValue placeholder="Persona" /></SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Todas las personas</SelectItem>
              <SelectItem value="__none__person__">ND (yo mismo)</SelectItem>
              {people.map((p) => (<SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardHeader className="pb-2"><CardTitle className="text-base">Registros</CardTitle></CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Fecha</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Cuenta</TableHead>
                <TableHead>Categoría</TableHead>
                <TableHead>Persona</TableHead>
                <TableHead>Descripción</TableHead>
                <TableHead className="text-right">Soles</TableHead>
                <TableHead className="text-right">USD</TableHead>
                <TableHead className="w-[120px]">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">
                    Sin movimientos con esos filtros.
                  </TableCell>
                </TableRow>
              ) : filtered.slice(0, 500).map((t) => {
                const cat = t.category_id ? categoriesById.get(t.category_id) : null;
                const accName = t.tx_type === "transfer"
                  ? `${accountsById.get(t.origin_account_id ?? "")?.name ?? "—"} → ${accountsById.get(t.destination_account_id ?? "")?.name ?? "—"}`
                  : accountsById.get(t.payment_account_id ?? "")?.name ?? "—";
                const person = t.person_id ? peopleById.get(t.person_id)?.name : "ND";
                const tone =
                  t.tx_type === "income" ? "bg-success/15 text-success border-success/30" :
                  t.tx_type === "expense" ? "bg-destructive/15 text-destructive border-destructive/30" :
                  "bg-primary/15 text-primary border-primary/30";
                const label = t.tx_type === "expense" ? "Gasto" : t.tx_type === "income" ? "Ingreso" : "TI";
                return (
                  <TableRow key={t.id} className="hover:bg-muted/30">
                    <TableCell className="text-xs">{formatDate(t.tx_date)}</TableCell>
                    <TableCell><Badge variant="outline" className={tone}>{label}</Badge></TableCell>
                    <TableCell className="text-xs max-w-[180px] truncate">{accName}</TableCell>
                    <TableCell className="text-xs">{cat?.name ?? "—"}</TableCell>
                    <TableCell className="text-xs">{person}</TableCell>
                    <TableCell className="text-xs max-w-[220px] truncate">{t.description ?? "—"}</TableCell>
                    <TableCell className="text-right text-xs font-medium">
                      {Number(t.amount_pen) > 0 ? formatPEN(t.amount_pen) : "—"}
                    </TableCell>
                    <TableCell className="text-right text-xs font-medium">
                      {Number(t.amount_usd) > 0 ? formatUSD(t.amount_usd) : "—"}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setViewing(t)}>
                          <Eye className="h-3.5 w-3.5" />
                        </Button>
                        {isAdmin && (
                          <>
                            <Button size="icon" variant="ghost" className="h-7 w-7"
                              onClick={() => { setEditing(t); setDuplicating(null); setOpen(true); }}
                              title="Editar">
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7"
                              onClick={() => { setEditing(null); setDuplicating(t); setOpen(true); }}
                              title="Duplicar">
                              <Copy className="h-3.5 w-3.5" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive hover:text-destructive"
                              onClick={() => handleDelete(t.id)} title="Eliminar">
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <TransactionFormDialog
        open={open}
        onClose={() => { setOpen(false); setEditing(null); setDuplicating(null); }}
        initial={editing}
        prefill={duplicating}
      />

      <Dialog open={!!viewing} onOpenChange={() => setViewing(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Detalle del movimiento</DialogTitle></DialogHeader>
          {viewing && (
            <div className="space-y-2 text-sm">
              <Row k="Fecha" v={formatDate(viewing.tx_date)} />
              <Row k="Tipo" v={viewing.tx_type === "expense" ? "Gasto" : viewing.tx_type === "income" ? "Ingreso" : "TI"} />
              {viewing.tx_type !== "transfer" && (
                <Row k="Medio de pago" v={accountsById.get(viewing.payment_account_id ?? "")?.name ?? "—"} />
              )}
              {viewing.tx_type === "transfer" && (
                <>
                  <Row k="Origen" v={accountsById.get(viewing.origin_account_id ?? "")?.name ?? "—"} />
                  <Row k="Destino" v={accountsById.get(viewing.destination_account_id ?? "")?.name ?? "—"} />
                </>
              )}
              <Row k="Categoría" v={viewing.category_id ? categoriesById.get(viewing.category_id)?.name ?? "—" : "—"} />
              <Row k="Referente a" v={viewing.person_id ? peopleById.get(viewing.person_id)?.name ?? "ND" : "ND"} />
              <Row k="Soles" v={Number(viewing.amount_pen) > 0 ? formatPEN(viewing.amount_pen) : "—"} />
              <Row k="Dólares" v={Number(viewing.amount_usd) > 0 ? formatUSD(viewing.amount_usd) : "—"} />
              <div>
                <div className="text-xs text-muted-foreground mb-1">Descripción completa</div>
                <div className="bg-muted/40 rounded-md p-3 whitespace-pre-wrap break-words">
                  {viewing.description || "—"}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

const Row = ({ k, v }: { k: string; v: string }) => (
  <div className="flex justify-between gap-4 border-b border-border/40 pb-1.5">
    <span className="text-muted-foreground">{k}</span>
    <span className="font-medium text-right">{v}</span>
  </div>
);

export default Movimientos;
