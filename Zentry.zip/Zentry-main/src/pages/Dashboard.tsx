import { useMemo, useState } from "react";
import { useAccounts, useCategories, useTransactions, type Transaction } from "@/hooks/useFinanceData";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatPEN, formatUSD, formatDate, monthName, monthsList } from "@/lib/format";
import {
  TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, CalendarDays,
  ChevronLeft, ChevronRight, Plus, PiggyBank, Receipt, Sparkles,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell,
} from "recharts";
import TransactionFormDialog from "@/components/TransactionFormDialog";

const CHART_COLORS = [
  "hsl(var(--chart-1))","hsl(var(--chart-2))","hsl(var(--chart-3))","hsl(var(--chart-4))","hsl(var(--chart-5))",
  "hsl(var(--chart-6))","hsl(var(--chart-7))","hsl(var(--chart-8))","hsl(var(--chart-9))","hsl(var(--chart-10))",
];

const isExtraordinary = (accountId: string | null, accountsById: Map<string, any>) => {
  if (!accountId) return false;
  const a = accountsById.get(accountId);
  return a?.name === "Otros - Exterior" || a?.name === "Negocio Papá";
};

const Dashboard = () => {
  const { isAdmin } = useAuth();
  const { data: accounts = [] } = useAccounts();
  const { data: categories = [] } = useCategories();
  const { data: txs = [] } = useTransactions();

  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth() + 1);
  const [newTxOpen, setNewTxOpen] = useState(false);

  const accountsById = useMemo(() => new Map(accounts.map((a) => [a.id, a])), [accounts]);
  const categoriesById = useMemo(() => new Map(categories.map((c) => [c.id, c])), [categories]);

  const navMonth = (delta: number) => {
    let y = year;
    let m = month + delta;
    if (m < 1) { m = 12; y--; }
    if (m > 12) { m = 1; y++; }
    setYear(y); setMonth(m);
  };

  const years = useMemo(() => {
    const ys = new Set<number>([today.getFullYear()]);
    txs.forEach((t) => ys.add(parseInt(t.tx_date.slice(0, 4))));
    return Array.from(ys).sort((a, b) => b - a);
  }, [txs]);

  const monthTxs = useMemo(() => {
    return txs.filter((t) => {
      const [y, m] = t.tx_date.split("-").map(Number);
      return y === year && m === month;
    });
  }, [txs, year, month]);

  // Filter out extraordinary accounts for dashboard income/expense
  const isCounted = (t: Transaction) =>
    !isExtraordinary(t.payment_account_id, accountsById) &&
    !isExtraordinary(t.origin_account_id, accountsById) &&
    !isExtraordinary(t.destination_account_id, accountsById);

  const totalIncome = monthTxs
    .filter((t) => t.tx_type === "income" && isCounted(t))
    .reduce((s, t) => s + Number(t.amount_pen || 0), 0);
  const totalIncomeUSD = monthTxs
    .filter((t) => t.tx_type === "income" && isCounted(t))
    .reduce((s, t) => s + Number(t.amount_usd || 0), 0);

  const totalExpense = monthTxs
    .filter((t) => t.tx_type === "expense" && isCounted(t))
    .reduce((s, t) => s + Number(t.amount_pen || 0), 0);
  const totalExpenseUSD = monthTxs
    .filter((t) => t.tx_type === "expense" && isCounted(t))
    .reduce((s, t) => s + Number(t.amount_usd || 0), 0);

  const balance = totalIncome - totalExpense;
  const balanceUSD = totalIncomeUSD - totalExpenseUSD;

  // Pie data for expenses
  const expensePie = useMemo(() => {
    const map = new Map<string, { name: string; value: number; categoryId: string }>();
    monthTxs.filter((t) => t.tx_type === "expense" && isCounted(t)).forEach((t) => {
      const cat = t.category_id ? categoriesById.get(t.category_id) : null;
      const name = cat?.name ?? "Sin categoría";
      const key = t.category_id ?? "none";
      const cur = map.get(key) ?? { name, value: 0, categoryId: key };
      cur.value += Number(t.amount_pen || 0);
      map.set(key, cur);
    });
    return Array.from(map.values()).filter((d) => d.value > 0).sort((a, b) => b.value - a.value);
  }, [monthTxs, categoriesById]);

  const incomePie = useMemo(() => {
    const map = new Map<string, { name: string; value: number; categoryId: string }>();
    monthTxs.filter((t) => t.tx_type === "income" && isCounted(t)).forEach((t) => {
      const cat = t.category_id ? categoriesById.get(t.category_id) : null;
      const name = cat?.name ?? "Sin categoría";
      const key = t.category_id ?? "none";
      const cur = map.get(key) ?? { name, value: 0, categoryId: key };
      cur.value += Number(t.amount_pen || 0);
      map.set(key, cur);
    });
    return Array.from(map.values()).filter((d) => d.value > 0).sort((a, b) => b.value - a.value);
  }, [monthTxs, categoriesById]);

  // Yearly trend (income & expense per month)
  const yearTrend = useMemo(() => {
    const arr = monthsList.map((label, i) => ({ month: label.slice(0, 3), ingresos: 0, gastos: 0, m: i + 1 }));
    txs.forEach((t) => {
      const [y, m] = t.tx_date.split("-").map(Number);
      if (y !== year || !isCounted(t)) return;
      if (t.tx_type === "income") arr[m - 1].ingresos += Number(t.amount_pen || 0);
      if (t.tx_type === "expense") arr[m - 1].gastos += Number(t.amount_pen || 0);
    });
    return arr;
  }, [txs, year, accountsById]);

  // Today's movements
  const todayStr = today.toISOString().slice(0, 10);
  const todayTxs = useMemo(
    () => txs.filter((t) => t.tx_date === todayStr).slice(0, 20),
    [txs, todayStr]
  );

  // Drill-down state
  const [expenseDrill, setExpenseDrill] = useState<string | null>(null);
  const [incomeDrill, setIncomeDrill] = useState<string | null>(null);

  const expenseDrillTxs = monthTxs.filter(
    (t) => t.tx_type === "expense" && isCounted(t) && t.category_id === expenseDrill
  );
  const incomeDrillTxs = monthTxs.filter(
    (t) => t.tx_type === "income" && isCounted(t) && t.category_id === incomeDrill
  );

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-primary/20 border border-primary/30 flex items-center justify-center">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight gradient-text">Dashboard</h1>
            <p className="text-xs text-muted-foreground">Tu panorama financiero</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* Month navigator with arrows */}
          <div className="flex items-center bg-card/60 border border-border/60 rounded-lg backdrop-blur-md">
            <Button variant="ghost" size="icon" className="h-9 w-9 rounded-r-none" onClick={() => navMonth(-1)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <div className="px-4 py-1.5 min-w-[150px] text-center text-sm font-semibold border-x border-border/60">
              {monthName(month)} {year}
            </div>
            <Button variant="ghost" size="icon" className="h-9 w-9 rounded-l-none" onClick={() => navMonth(1)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          {isAdmin && (
            <Button onClick={() => setNewTxOpen(true)} className="bg-gradient-primary text-primary-foreground hover:opacity-90">
              <Plus className="h-4 w-4 mr-1" /> Nuevo
            </Button>
          )}
        </div>
      </div>

      {/* TOP ROW: 3 KPI cards stacked + yearly trend on the right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4 lg:col-span-1">
          <KpiCard
            title="Ingresos del mes"
            value={formatPEN(totalIncome)}
            usd={totalIncomeUSD ? formatUSD(totalIncomeUSD) : null}
            icon={<PiggyBank className="h-5 w-5 text-success" />}
            color="success"
          />
          <KpiCard
            title="Gastos del mes"
            value={formatPEN(totalExpense)}
            usd={totalExpenseUSD ? formatUSD(totalExpenseUSD) : null}
            icon={<Receipt className="h-5 w-5 text-destructive" />}
            color="destructive"
          />
          <KpiCard
            title="Balance"
            value={formatPEN(balance)}
            usd={(totalIncomeUSD || totalExpenseUSD) ? formatUSD(balanceUSD) : null}
            icon={<Sparkles className="h-5 w-5 text-primary" />}
            color={balance >= 0 ? "primary" : "destructive"}
          />
        </div>

        <Card className="glass-card lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Tendencia anual {year}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={yearTrend}>
                <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 8,
                  }}
                  formatter={(v: number) => formatPEN(v)}
                />
                <Bar dataKey="ingresos" name="Ingresos" fill="hsl(var(--success))" radius={[4, 4, 0, 0]} />
                <Bar dataKey="gastos" name="Gastos" fill="hsl(var(--destructive))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* MIDDLE ROW: Expense pie + Income pie side by side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <PieCard
          title="Gastos del mes"
          data={expensePie}
          activeId={expenseDrill}
          onSlice={(id) => setExpenseDrill((prev) => (prev === id ? null : id))}
          emptyText="Sin gastos este mes"
        />
        <PieCard
          title="Ingresos del mes"
          data={incomePie}
          activeId={incomeDrill}
          onSlice={(id) => setIncomeDrill((prev) => (prev === id ? null : id))}
          emptyText="Sin ingresos este mes"
        />
      </div>

      {/* Drill-down details */}
      {expenseDrill && expenseDrillTxs.length > 0 && (
        <DrillDownCard
          title={`Detalle de gastos · ${categoriesById.get(expenseDrill)?.name ?? ""}`}
          txs={expenseDrillTxs}
          tone="destructive"
        />
      )}
      {incomeDrill && incomeDrillTxs.length > 0 && (
        <DrillDownCard
          title={`Detalle de ingresos · ${categoriesById.get(incomeDrill)?.name ?? ""}`}
          txs={incomeDrillTxs}
          tone="success"
        />
      )}

      {/* Today's movements */}
      <Card className="glass-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <CalendarDays className="h-4 w-4 text-primary" />
            Movimientos de hoy
          </CardTitle>
        </CardHeader>
        <CardContent>
          {todayTxs.length === 0 ? (
            <p className="text-sm text-muted-foreground py-6 text-center">
              No hay movimientos registrados hoy.
            </p>
          ) : (
            <div className="space-y-2">
              {todayTxs.map((t) => {
                const cat = t.category_id ? categoriesById.get(t.category_id) : null;
                const acc = t.payment_account_id ? accountsById.get(t.payment_account_id) : null;
                const sign = t.tx_type === "income" ? "+" : t.tx_type === "expense" ? "-" : "";
                const tone =
                  t.tx_type === "income" ? "text-success" :
                  t.tx_type === "expense" ? "text-destructive" : "text-muted-foreground";
                return (
                  <div key={t.id} className="flex items-center justify-between gap-3 py-2 border-b border-border/40 last:border-0">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`w-8 h-8 rounded-md flex items-center justify-center bg-muted/50 ${tone}`}>
                        {t.tx_type === "income" ? <TrendingUp className="h-4 w-4" /> :
                         t.tx_type === "expense" ? <TrendingDown className="h-4 w-4" /> :
                         <ArrowUpRight className="h-4 w-4" />}
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium truncate">{cat?.name ?? "—"}</div>
                        <div className="text-xs text-muted-foreground truncate">
                          {acc?.name ?? ""} {t.description ? `· ${t.description}` : ""}
                        </div>
                      </div>
                    </div>
                    <div className={`text-sm font-semibold ${tone}`}>
                      {sign}{Number(t.amount_pen) > 0 ? formatPEN(t.amount_pen) : formatUSD(t.amount_usd)}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <TransactionFormDialog open={newTxOpen} onClose={() => setNewTxOpen(false)} initial={null} />
    </div>
  );
};

const KpiCard = ({
  title, value, usd, icon, color,
}: {
  title: string; value: string; usd: string | null;
  icon: React.ReactNode; color: "success" | "destructive" | "primary";
}) => {
  const ring =
    color === "success" ? "border-success/20" :
    color === "destructive" ? "border-destructive/20" : "border-primary/30";
  return (
    <Card className={`glass-card glow-on-hover ${ring}`}>
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wide">{title}</p>
            <p className="text-2xl font-bold mt-1">{value}</p>
            {usd && <p className="text-xs text-muted-foreground mt-1">≈ {usd}</p>}
          </div>
          <div className="w-9 h-9 rounded-lg bg-muted/40 flex items-center justify-center">{icon}</div>
        </div>
      </CardContent>
    </Card>
  );
};

const PieCard = ({
  title, data, activeId, onSlice, emptyText,
}: {
  title: string;
  data: { name: string; value: number; categoryId: string }[];
  activeId: string | null;
  onSlice: (id: string) => void;
  emptyText: string;
}) => {
  const total = data.reduce((s, d) => s + d.value, 0);
  return (
    <Card className="glass-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-base">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        {data.length === 0 ? (
          <p className="text-sm text-muted-foreground py-12 text-center">{emptyText}</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={data}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={50}
                  outerRadius={85}
                  paddingAngle={2}
                  onClick={(d: any) => onSlice(d.categoryId)}
                  cursor="pointer"
                >
                  {data.map((d, i) => (
                    <Cell
                      key={d.categoryId}
                      fill={CHART_COLORS[i % CHART_COLORS.length]}
                      stroke={activeId === d.categoryId ? "hsl(var(--foreground))" : "transparent"}
                      strokeWidth={2}
                    />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 8,
                  }}
                  formatter={(v: number) => formatPEN(v)}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-1.5 max-h-[220px] overflow-y-auto pr-2">
              {data.map((d, i) => {
                const pct = total > 0 ? (d.value / total) * 100 : 0;
                const active = activeId === d.categoryId;
                return (
                  <button
                    key={d.categoryId}
                    onClick={() => onSlice(d.categoryId)}
                    className={`w-full flex items-center justify-between gap-2 px-2 py-1.5 rounded-md text-left text-sm transition ${
                      active ? "bg-primary/15 ring-1 ring-primary/40" : "hover:bg-muted/40"
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="w-2.5 h-2.5 rounded-sm flex-shrink-0"
                        style={{ background: CHART_COLORS[i % CHART_COLORS.length] }}
                      />
                      <span className="truncate">{d.name}</span>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className="text-xs font-medium">{formatPEN(d.value)}</span>
                      <span className="text-[10px] text-muted-foreground">{pct.toFixed(1)}%</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

const DrillDownCard = ({ title, txs, tone }: { title: string; txs: Transaction[]; tone: "success" | "destructive" }) => {
  const toneClass = tone === "success" ? "text-success" : "text-destructive";
  return (
    <Card className="glass-card animate-fade-in">
      <CardHeader className="pb-2">
        <CardTitle className="text-base">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="divide-y divide-border/40">
          {txs.map((t) => (
            <div key={t.id} className="flex items-center justify-between py-2 gap-3">
              <div className="flex flex-col min-w-0">
                <span className="text-sm font-medium">{formatDate(t.tx_date)}</span>
                <span className="text-xs text-muted-foreground truncate">{t.description ?? "Sin comentario"}</span>
              </div>
              <span className={`text-sm font-semibold ${toneClass}`}>
                {Number(t.amount_pen) > 0 ? formatPEN(t.amount_pen) : formatUSD(t.amount_usd)}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default Dashboard;
