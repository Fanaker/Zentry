import { useState } from "react";
import * as XLSX from "xlsx";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import {
  useAccounts, useCategories, usePeople, useTransactions,
} from "@/hooks/useFinanceData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Upload, FileSpreadsheet, Loader2, History } from "lucide-react";
import { toast } from "sonner";
import { monthName } from "@/lib/format";

const TYPE_TO_ES: Record<string, string> = { expense: "Gasto", income: "Ingreso", transfer: "TI" };
const ES_TO_TYPE: Record<string, "expense" | "income" | "transfer"> = {
  "gasto": "expense", "ingreso": "income", "ti": "transfer",
};

const Datos = () => {
  const { isAdmin, user } = useAuth();
  const qc = useQueryClient();
  const { data: accounts = [] } = useAccounts();
  const { data: categories = [] } = useCategories();
  const { data: people = [] } = usePeople();
  const { data: txs = [] } = useTransactions();

  const { data: backups = [] } = useQuery({
    queryKey: ["backup_history"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("backup_history")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data ?? [];
    },
  });

  const [importing, setImporting] = useState(false);

  const handleExport = async () => {
    const accById = new Map(accounts.map((a) => [a.id, a]));
    const catById = new Map(categories.map((c) => [c.id, c]));
    const personById = new Map(people.map((p) => [p.id, p]));

    const rows = txs.map((t) => {
      const [y, m] = t.tx_date.split("-").map(Number);
      const isTransfer = t.tx_type === "transfer";
      return {
        Fecha: t.tx_date,
        Mes: monthName(m),
        Tipo: TYPE_TO_ES[t.tx_type] ?? t.tx_type,
        "Medio de Pago": isTransfer ? "" : (accById.get(t.payment_account_id ?? "")?.name ?? ""),
        Origen: isTransfer ? (accById.get(t.origin_account_id ?? "")?.name ?? "") : "",
        Destino: isTransfer ? (accById.get(t.destination_account_id ?? "")?.name ?? "") : "",
        "Referente a": t.person_id ? (personById.get(t.person_id)?.name ?? "ND") : "ND",
        Categoría: t.category_id ? (catById.get(t.category_id)?.name ?? "") : "",
        Descripción: t.description ?? "",
        Soles: Number(t.amount_pen) || 0,
        Dólares: Number(t.amount_usd) || 0,
      };
    });

    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Datos");
    const filename = `zentry-respaldo-${new Date().toISOString().slice(0, 10)}.xlsx`;
    XLSX.writeFile(wb, filename);

    // Log backup event
    if (isAdmin) {
      await supabase.from("backup_history").insert({
        filename,
        record_count: rows.length,
        created_by: user?.id ?? null,
      });
      qc.invalidateQueries({ queryKey: ["backup_history"] });
    }

    toast.success(`${rows.length} registros exportados`);
  };

  const handleImport = async (file: File) => {
    if (!isAdmin) return;
    setImporting(true);
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf);
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows: any[] = XLSX.utils.sheet_to_json(ws, { defval: "" });

      const accByName = new Map(accounts.map((a) => [a.name.toLowerCase().trim(), a]));
      const catByKey = new Map(
        categories.map((c) => [`${c.tx_type}:${c.name.toLowerCase().trim()}`, c])
      );
      const personByName = new Map(people.map((p) => [p.name.toLowerCase().trim(), p]));

      const ensurePerson = async (name: string) => {
        const key = name.toLowerCase().trim();
        if (personByName.has(key)) return personByName.get(key)!.id;
        const { data, error } = await supabase.from("people").insert({ name: name.trim() }).select("id, name").single();
        if (error) {
          const { data: existing } = await supabase.from("people").select("id, name").eq("name", name.trim()).maybeSingle();
          if (existing) {
            personByName.set(key, existing as any);
            return existing.id;
          }
          throw error;
        }
        personByName.set(key, data as any);
        return data.id;
      };

      const inferAccountType = (name: string): "credit" | "dollars" | "cash" | "debit" | "other" => {
        const n = name.trim();
        if (n.toLowerCase() === "efectivo") return "cash";
        if (n.startsWith("C.")) return "credit";
        if (n.toLowerCase().startsWith("dólares") || n.toLowerCase().startsWith("dolares")) return "dollars";
        return "debit";
      };

      const ensureAccount = async (name: string) => {
        const key = name.toLowerCase().trim();
        if (accByName.has(key)) return accByName.get(key)!.id;
        const type = inferAccountType(name);
        const currency = type === "dollars" ? "USD" : "PEN";
        const { data, error } = await supabase
          .from("accounts")
          .insert({ name: name.trim(), account_type: type, currency })
          .select("*")
          .single();
        if (error) {
          const { data: existing } = await supabase.from("accounts").select("*").eq("name", name.trim()).maybeSingle();
          if (existing) { accByName.set(key, existing as any); return existing.id; }
          throw error;
        }
        accByName.set(key, data as any);
        return data.id;
      };

      const ensureCategory = async (name: string, txType: "expense" | "income" | "transfer") => {
        const k = `${txType}:${name.toLowerCase().trim()}`;
        if (catByKey.has(k)) return catByKey.get(k)!.id;
        const { data, error } = await supabase
          .from("categories")
          .insert({ name: name.trim(), tx_type: txType })
          .select("*")
          .single();
        if (error) {
          const { data: existing } = await supabase
            .from("categories")
            .select("*")
            .eq("name", name.trim())
            .eq("tx_type", txType)
            .maybeSingle();
          if (existing) { catByKey.set(k, existing as any); return existing.id; }
          throw error;
        }
        catByKey.set(k, data as any);
        return data.id;
      };

      let imported = 0, skipped = 0;
      const batch: any[] = [];

      for (const r of rows) {
        const fecha = r["Fecha"];
        const tipoRaw = String(r["Tipo"] ?? "").trim().toLowerCase();
        const txType = ES_TO_TYPE[tipoRaw];
        if (!txType || !fecha) { skipped++; continue; }

        let tx_date: string;
        if (typeof fecha === "number") {
          const d = XLSX.SSF.parse_date_code(fecha);
          tx_date = `${d.y}-${String(d.m).padStart(2, "0")}-${String(d.d).padStart(2, "0")}`;
        } else {
          const s = String(fecha).slice(0, 10);
          if (/^\d{4}-\d{2}-\d{2}$/.test(s)) tx_date = s;
          else if (/^\d{2}\/\d{2}\/\d{4}$/.test(s)) {
            const [d, m, y] = s.split("/");
            tx_date = `${y}-${m}-${d}`;
          } else { skipped++; continue; }
        }

        const medio = String(r["Medio de Pago"] ?? "").trim();
        const origen = String(r["Origen"] ?? "").trim();
        const destino = String(r["Destino"] ?? "").trim();
        const referente = String(r["Referente a"] ?? "").trim();
        const categoria = String(r["Categoría"] ?? r["Categoria"] ?? "").trim();
        const descripcion = String(r["Descripción"] ?? r["Descripcion"] ?? "").trim() || null;
        const soles = Number(r["Soles"] ?? 0) || 0;
        const dolares = Number(r["Dólares"] ?? r["Dolares"] ?? 0) || 0;

        const payload: any = {
          tx_date, tx_type: txType,
          amount_pen: soles, amount_usd: dolares,
          currency: dolares > 0 && soles === 0 ? "USD" : "PEN",
          description: descripcion,
          payment_account_id: null, origin_account_id: null, destination_account_id: null,
          category_id: null, person_id: null,
        };

        if (txType === "transfer") {
          if (origen) payload.origin_account_id = await ensureAccount(origen);
          if (destino) payload.destination_account_id = await ensureAccount(destino);
        } else if (medio) {
          payload.payment_account_id = await ensureAccount(medio);
        }
        if (categoria) payload.category_id = await ensureCategory(categoria, txType);
        if (referente && referente.toUpperCase() !== "ND") {
          payload.person_id = await ensurePerson(referente);
        }

        batch.push(payload);
        imported++;
      }

      // Insert in chunks of 200
      for (let i = 0; i < batch.length; i += 200) {
        const chunk = batch.slice(i, i + 200);
        const { error } = await supabase.from("transactions").insert(chunk);
        if (error) throw error;
      }

      toast.success(`${imported} registros importados${skipped ? ` · ${skipped} omitidos` : ""}`);
      qc.invalidateQueries();
    } catch (err: any) {
      toast.error(err.message ?? "Error al importar");
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Importar / Exportar</h1>
        <p className="text-sm text-muted-foreground">Respaldo y migración de tus datos en formato Excel.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Download className="h-4 w-4 text-primary" /> Exportar respaldo
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Genera un Excel con todos tus movimientos en el mismo orden de columnas:
              <span className="block mt-1 font-mono text-[11px]">
                Fecha · Mes · Tipo · Medio de Pago · Origen · Destino · Referente a · Categoría · Descripción · Soles · Dólares
              </span>
            </p>
            <Button onClick={handleExport} className="w-full">
              <FileSpreadsheet className="h-4 w-4 mr-2" /> Descargar Excel
            </Button>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Upload className="h-4 w-4 text-primary" /> Importar desde Excel
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Sube tu archivo .xlsx con la estructura clásica. Las cuentas que empiezan con
              <span className="font-mono"> "C." </span> se marcan como crédito, las que inician con
              <span className="font-mono"> "Dólares" </span> como cuentas en dólares, "Efectivo" como efectivo y el resto como débito.
            </p>
            <input
              type="file"
              accept=".xlsx,.xls"
              disabled={!isAdmin || importing}
              onChange={(e) => e.target.files?.[0] && handleImport(e.target.files[0])}
              className="block w-full text-sm file:mr-3 file:py-2 file:px-4 file:rounded-md file:border-0 file:bg-primary file:text-primary-foreground file:cursor-pointer disabled:opacity-50"
            />
            {importing && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Importando…
              </div>
            )}
            {!isAdmin && (
              <p className="text-xs text-warning">Solo los administradores pueden importar.</p>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <History className="h-4 w-4 text-primary" /> Historial de respaldos
          </CardTitle>
        </CardHeader>
        <CardContent>
          {backups.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">
              Aún no has generado ningún respaldo. Cuando exportes un Excel, se registrará aquí la fecha y hora.
            </p>
          ) : (
            <div className="divide-y divide-border/40">
              {backups.map((b: any) => {
                const d = new Date(b.created_at);
                const fecha = d.toLocaleDateString("es-PE", { day: "2-digit", month: "long", year: "numeric" });
                const hora = d.toLocaleTimeString("es-PE", { hour: "2-digit", minute: "2-digit" });
                return (
                  <div key={b.id} className="flex justify-between items-center gap-3 py-2.5">
                    <div className="min-w-0">
                      <div className="text-sm font-medium">{fecha} · {hora}</div>
                      <div className="text-xs text-muted-foreground truncate">{b.filename}</div>
                    </div>
                    <span className="text-xs px-2 py-1 rounded-md bg-primary/15 text-primary border border-primary/30">
                      {b.record_count} registros
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Datos;
