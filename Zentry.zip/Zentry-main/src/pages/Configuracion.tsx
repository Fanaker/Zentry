import { useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useAccounts, useCategories } from "@/hooks/useFinanceData";
import { Navigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

const Configuracion = () => {
  const { isAdmin } = useAuth();
  const qc = useQueryClient();
  const { data: accounts = [] } = useAccounts();
  const { data: categories = [] } = useCategories();

  if (!isAdmin) return <Navigate to="/" replace />;

  const [newAccount, setNewAccount] = useState({ name: "", account_type: "debit" as any, currency: "PEN" as any, counts_as_real_money: true });
  const [newCat, setNewCat] = useState({ name: "", tx_type: "expense" as any });

  const addAccount = async () => {
    if (!newAccount.name.trim()) return;
    const { error } = await supabase.from("accounts").insert(newAccount);
    if (error) toast.error(error.message);
    else { toast.success("Cuenta creada"); qc.invalidateQueries({ queryKey: ["accounts"] }); setNewAccount({ ...newAccount, name: "" }); }
  };

  const toggleRealMoney = async (id: string, value: boolean) => {
    const { error } = await supabase.from("accounts").update({ counts_as_real_money: value }).eq("id", id);
    if (error) toast.error(error.message);
    else qc.invalidateQueries({ queryKey: ["accounts"] });
  };

  const deleteAccount = async (id: string) => {
    if (!confirm("¿Eliminar esta cuenta? Los movimientos asociados quedarán sin cuenta.")) return;
    const { error } = await supabase.from("accounts").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Cuenta eliminada"); qc.invalidateQueries({ queryKey: ["accounts"] }); }
  };

  const addCategory = async () => {
    if (!newCat.name.trim()) return;
    const { error } = await supabase.from("categories").insert(newCat);
    if (error) toast.error(error.message);
    else { toast.success("Categoría creada"); qc.invalidateQueries({ queryKey: ["categories"] }); setNewCat({ ...newCat, name: "" }); }
  };

  const deleteCategory = async (id: string) => {
    if (!confirm("¿Eliminar esta categoría?")) return;
    const { error } = await supabase.from("categories").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Categoría eliminada"); qc.invalidateQueries({ queryKey: ["categories"] }); }
  };

  const groupedCats = useMemo(() => ({
    expense: categories.filter((c) => c.tx_type === "expense"),
    income: categories.filter((c) => c.tx_type === "income"),
    transfer: categories.filter((c) => c.tx_type === "transfer"),
  }), [categories]);

  return (
    <div className="space-y-4 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Configuración</h1>
        <p className="text-sm text-muted-foreground">Cuentas, categorías y permisos.</p>
      </div>

      <Tabs defaultValue="accounts">
        <TabsList>
          <TabsTrigger value="accounts">Cuentas</TabsTrigger>
          <TabsTrigger value="categories">Categorías</TabsTrigger>
          <TabsTrigger value="users">Usuarios</TabsTrigger>
        </TabsList>

        <TabsContent value="accounts" className="space-y-4">
          <Card className="glass-card">
            <CardHeader className="pb-2"><CardTitle className="text-base">Nueva cuenta</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-[1fr,140px,120px,auto,auto] gap-2">
              <Input placeholder="Nombre" value={newAccount.name} onChange={(e) => setNewAccount({ ...newAccount, name: e.target.value })} />
              <Select value={newAccount.account_type} onValueChange={(v) => setNewAccount({ ...newAccount, account_type: v as any })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="debit">Débito</SelectItem>
                  <SelectItem value="credit">Crédito</SelectItem>
                  <SelectItem value="cash">Efectivo</SelectItem>
                  <SelectItem value="dollars">Dólares</SelectItem>
                  <SelectItem value="other">Otro</SelectItem>
                </SelectContent>
              </Select>
              <Select value={newAccount.currency} onValueChange={(v) => setNewAccount({ ...newAccount, currency: v as any })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="PEN">PEN</SelectItem>
                  <SelectItem value="USD">USD</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex items-center gap-2 px-2">
                <Switch checked={newAccount.counts_as_real_money} onCheckedChange={(v) => setNewAccount({ ...newAccount, counts_as_real_money: v })} />
                <span className="text-xs">Dinero real</span>
              </div>
              <Button onClick={addAccount}><Plus className="h-4 w-4" /></Button>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardContent className="p-2">
              {accounts.map((a) => (
                <div key={a.id} className="flex items-center justify-between gap-3 p-3 border-b border-border/40 last:border-0">
                  <div>
                    <div className="text-sm font-medium">{a.name}</div>
                    <div className="text-xs text-muted-foreground">{a.account_type} · {a.currency}</div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <Switch checked={a.counts_as_real_money} onCheckedChange={(v) => toggleRealMoney(a.id, v)} />
                      <span className="text-xs">Cuenta como dinero real</span>
                    </div>
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={() => deleteAccount(a.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories" className="space-y-4">
          <Card className="glass-card">
            <CardHeader className="pb-2"><CardTitle className="text-base">Nueva categoría</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-[1fr,160px,auto] gap-2">
              <Input placeholder="Nombre" value={newCat.name} onChange={(e) => setNewCat({ ...newCat, name: e.target.value })} />
              <Select value={newCat.tx_type} onValueChange={(v) => setNewCat({ ...newCat, tx_type: v as any })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="expense">Gasto</SelectItem>
                  <SelectItem value="income">Ingreso</SelectItem>
                  <SelectItem value="transfer">TI</SelectItem>
                </SelectContent>
              </Select>
              <Button onClick={addCategory}><Plus className="h-4 w-4" /></Button>
            </CardContent>
          </Card>

          {(["expense", "income", "transfer"] as const).map((tt) => (
            <Card key={tt} className="glass-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">
                  {tt === "expense" ? "Gastos" : tt === "income" ? "Ingresos" : "Transferencias internas"}
                </CardTitle>
              </CardHeader>
              <CardContent className="flex flex-wrap gap-2">
                {groupedCats[tt].map((c) => (
                  <Badge key={c.id} variant="outline" className="px-3 py-1.5 gap-2">
                    {c.name}
                    <button onClick={() => deleteCategory(c.id)} className="text-destructive hover:opacity-80">
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="users">
          <Card className="glass-card">
            <CardHeader><CardTitle className="text-base">Gestión de usuarios</CardTitle></CardHeader>
            <CardContent className="space-y-3 text-sm">
              <p className="text-muted-foreground">
                Para invitar a alguien con permiso de <b>solo lectura</b>:
              </p>
              <ol className="list-decimal pl-5 space-y-2 text-muted-foreground">
                <li>Pídele que se registre en la pantalla de inicio de sesión con su correo y contraseña.</li>
                <li>Cualquier nuevo usuario se crea automáticamente con rol <b>Viewer</b> (solo lectura).</li>
                <li>Si necesitas otorgar permisos de administrador, contáctame (o haz la asignación directa en Lovable Cloud).</li>
              </ol>
              <p className="text-xs text-muted-foreground pt-2 border-t border-border/40">
                El primer usuario registrado siempre se convierte en administrador automáticamente.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Configuracion;
