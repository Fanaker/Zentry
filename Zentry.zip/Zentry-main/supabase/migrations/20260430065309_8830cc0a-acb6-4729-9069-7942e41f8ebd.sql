-- Tighten SECURITY DEFINER functions
ALTER FUNCTION public.has_role(uuid, public.app_role) SET search_path = public;
ALTER FUNCTION public.is_admin(uuid) SET search_path = public;
ALTER FUNCTION public.handle_new_user() SET search_path = public;

REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.is_admin(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin(uuid) TO authenticated;

-- ============ SEED DATA ============
-- Accounts
INSERT INTO public.accounts (name, account_type, currency, counts_as_real_money, display_order) VALUES
  ('Efectivo', 'cash', 'PEN', true, 1),
  ('BCP Débito', 'debit', 'PEN', true, 2),
  ('BBVA Débito', 'debit', 'PEN', true, 3),
  ('Interbank Débito', 'debit', 'PEN', true, 4),
  ('Yape', 'debit', 'PEN', true, 5),
  ('Plin', 'debit', 'PEN', true, 6),
  ('C. BCP Crédito', 'credit', 'PEN', true, 10),
  ('C. BBVA Crédito', 'credit', 'PEN', true, 11),
  ('C. Interbank Crédito', 'credit', 'PEN', true, 12),
  ('Dólares BCP', 'dollars', 'USD', true, 20),
  ('Dólares Interbank', 'dollars', 'USD', true, 21),
  ('Otros - Exterior', 'other', 'PEN', false, 90),
  ('Negocio Papá', 'other', 'PEN', false, 91)
ON CONFLICT (name) DO NOTHING;

-- Categories: expenses
INSERT INTO public.categories (name, tx_type) VALUES
  ('Alimentación', 'expense'),
  ('Transporte', 'expense'),
  ('Vivienda', 'expense'),
  ('Servicios', 'expense'),
  ('Salud', 'expense'),
  ('Entretenimiento', 'expense'),
  ('Educación', 'expense'),
  ('Ropa', 'expense'),
  ('Suscripciones', 'expense'),
  ('Préstamos / Deudas', 'expense'),
  ('Regalos', 'expense'),
  ('Otros gastos', 'expense'),
  -- income
  ('Sueldo', 'income'),
  ('Freelance', 'income'),
  ('Deudas Cobradas', 'income'),
  ('Intereses', 'income'),
  ('Reembolsos', 'income'),
  ('Otros ingresos', 'income'),
  -- transfer
  ('Depósito', 'transfer'),
  ('Retiro', 'transfer'),
  ('Pago de tarjeta', 'transfer'),
  ('Cambio de moneda', 'transfer'),
  ('Transferencia entre cuentas', 'transfer')
ON CONFLICT (name, tx_type) DO NOTHING;