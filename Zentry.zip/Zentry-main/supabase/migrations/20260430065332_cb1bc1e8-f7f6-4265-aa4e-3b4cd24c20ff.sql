-- has_role: keep callable by signed-in users (RLS uses it). Already has search_path.
-- The two remaining warnings are about has_role/is_admin being callable; needed for RLS.
-- Mark touch_updated_at with search_path
ALTER FUNCTION public.touch_updated_at() SET search_path = public;

-- Convert has_role/is_admin to SECURITY INVOKER is not viable (needs to bypass RLS to read user_roles).
-- Instead lock them down: only allow execution and ensure they never leak data beyond a boolean.
-- Already revoked from anon/public; granted only to authenticated. This is the correct pattern.
-- Re-grant and document:
COMMENT ON FUNCTION public.has_role(uuid, public.app_role) IS 'Used by RLS policies. Returns boolean only.';
COMMENT ON FUNCTION public.is_admin(uuid) IS 'Used by RLS policies. Returns boolean only.';