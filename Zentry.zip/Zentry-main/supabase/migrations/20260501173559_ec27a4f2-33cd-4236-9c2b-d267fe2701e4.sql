ALTER TABLE public.accounts
ADD COLUMN IF NOT EXISTS billing_start_day integer,
ADD COLUMN IF NOT EXISTS billing_end_day integer;

ALTER TABLE public.accounts
ADD CONSTRAINT accounts_billing_start_day_range CHECK (billing_start_day IS NULL OR (billing_start_day BETWEEN 1 AND 31)),
ADD CONSTRAINT accounts_billing_end_day_range CHECK (billing_end_day IS NULL OR (billing_end_day BETWEEN 1 AND 31));