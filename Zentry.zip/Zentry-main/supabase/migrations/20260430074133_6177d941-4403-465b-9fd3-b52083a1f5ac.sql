-- Backup history table to track export events
CREATE TABLE public.backup_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID,
  filename TEXT NOT NULL,
  record_count INTEGER NOT NULL DEFAULT 0,
  notes TEXT
);

ALTER TABLE public.backup_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated read backups"
ON public.backup_history FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Admins write backups"
ON public.backup_history FOR ALL
TO authenticated
USING (public.is_admin(auth.uid()))
WITH CHECK (public.is_admin(auth.uid()));

CREATE INDEX idx_backup_history_created_at ON public.backup_history (created_at DESC);
